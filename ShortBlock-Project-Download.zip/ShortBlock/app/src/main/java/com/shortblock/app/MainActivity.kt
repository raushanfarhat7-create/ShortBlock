package com.shortblock.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (22 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFFF5F6FA.toInt())
        }
        val title = TextView(this).apply {
            text = "ShortBlock"
            textSize = 32f
            setTextColor(0xFF171923.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Shorts & Reels distraction blocker"
            textSize = 15f
            setTextColor(0xFF596273.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 28)
        }
        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFF252A34.toInt())
            setPadding(0, 10, 0, 24)
        }
        val enable = Button(this).apply {
            text = "Enable ShortBlock"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val refresh = Button(this).apply {
            text = "Refresh status"
            setOnClickListener { updateStatus() }
        }
        val note = TextView(this).apply {
            text = "Enable ‘ShortBlock screen blocker’ in Accessibility settings.\n\nWhen a supported Shorts/Reels screen is detected, a NOT AVAILABLE cover appears. Tap GO BACK to leave that screen.\n\nDetection depends on each social app’s layout and may need updates."
            textSize = 14f
            setTextColor(0xFF596273.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(enable)
        root.addView(refresh)
        root.addView(note)
        setContentView(root)
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
    }

    private fun updateStatus() {
        val manager = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName && it.resolveInfo.serviceInfo.name.endsWith("BlockerAccessibilityService") }
        status.text = if (enabled) "● Protection is ON" else "○ Protection is OFF — enable it below"
        status.setTextColor(if (enabled) 0xFF16834A.toInt() else 0xFFB45309.toInt())
    }
}
