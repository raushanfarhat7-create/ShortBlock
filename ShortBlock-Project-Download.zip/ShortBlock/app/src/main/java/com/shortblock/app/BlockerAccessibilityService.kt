package com.shortblock.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockerAccessibilityService : AccessibilityService() {
    private var cover: View? = null
    private var windowManager: WindowManager? = null
    private var lastBlockedPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        val supported = pkg == YOUTUBE || pkg == INSTAGRAM || pkg == FACEBOOK || pkg == FACEBOOK_LITE
        if (!supported) {
            removeCover()
            return
        }
        val root = rootInActiveWindow
        val blocked = root?.let { containsShortVideoMarker(it, pkg, 0) } ?: false
        if (blocked) showCover(pkg) else if (lastBlockedPackage != pkg || event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) removeCover()
    }

    private fun containsShortVideoMarker(node: AccessibilityNodeInfo, pkg: String, depth: Int): Boolean {
        if (depth > 18) return false
        val viewId = node.viewIdResourceName?.lowercase().orEmpty()
        val text = (node.text?.toString().orEmpty() + " " + node.contentDescription?.toString().orEmpty()).lowercase()
        val idMatch = when (pkg) {
            YOUTUBE -> listOf("shorts_player", "reel_recycler", "shorts_container", "reel_watch").any { viewId.contains(it) }
            INSTAGRAM -> listOf("reel_viewer", "clips_viewer", "reel_pager", "reels_media").any { viewId.contains(it) }
            FACEBOOK, FACEBOOK_LITE -> listOf("reel_viewer", "reels_video", "reel_player", "reels_surface").any { viewId.contains(it) }
            else -> false
        }
        if (idMatch) return true
        // Text fallback is intentionally conservative; generic navigation labels are ignored.
        val textMatch = when (pkg) {
            YOUTUBE -> text.contains("shorts player") || text.contains("shorts video")
            INSTAGRAM -> text.contains("reel by ") || text.contains("reels video") || text.contains("reel video")
            FACEBOOK, FACEBOOK_LITE -> text.contains("reels video") || text.contains("reel video")
            else -> false
        }
        if (textMatch) return true
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = containsShortVideoMarker(child, pkg, depth + 1)
            child.recycle()
            if (found) return true
        }
        return false
    }

    private fun showCover(pkg: String) {
        if (cover != null && lastBlockedPackage == pkg) return
        removeCover()
        lastBlockedPackage = pkg
        val density = resources.displayMetrics.density
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding((28 * density).toInt(), (28 * density).toInt(), (28 * density).toInt(), (28 * density).toInt())
            background = GradientDrawable().apply {
                setColor(Color.rgb(17, 24, 39))
                cornerRadius = 24 * density
            }
        }
        val heading = TextView(this).apply {
            text = "NOT AVAILABLE"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val message = TextView(this).apply {
            text = "Short videos are blocked.\nStay focused and use your time wisely."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, (18 * density).toInt(), 0, (26 * density).toInt())
        }
        val back = Button(this).apply {
            text = "GO BACK"
            setOnClickListener { performGlobalAction(GLOBAL_ACTION_BACK); removeCover() }
        }
        panel.addView(heading)
        panel.addView(message)
        panel.addView(back)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        windowManager?.addView(panel, params)
        cover = panel
    }

    private fun removeCover() {
        val old = cover ?: return
        try { windowManager?.removeView(old) } catch (_: Exception) { }
        cover = null
        lastBlockedPackage = null
    }

    override fun onInterrupt() { removeCover() }
    override fun onDestroy() { removeCover(); super.onDestroy() }

    companion object {
        private const val YOUTUBE = "com.google.android.youtube"
        private const val INSTAGRAM = "com.instagram.android"
        private const val FACEBOOK = "com.facebook.katana"
        private const val FACEBOOK_LITE = "com.facebook.lite"
    }
}
