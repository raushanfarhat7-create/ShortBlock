# ShortBlock (Android project)

এই প্রজেক্টটি YouTube Shorts, Instagram Reels এবং Facebook Reels-এর পরিচিত screen marker শনাক্ত করার চেষ্টা করে। শনাক্ত হলে `NOT AVAILABLE` overlay দেখায়। সাধারণ ভিডিও/ফিডে বাধা না দেওয়ার জন্য generic bottom-navigation label দিয়ে block করা হয় না।

## Android Studio-তে চালানোর নিয়ম
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio থেকে **Open** চাপুন এবং এই `ShortBlock` ফোল্ডারটি নির্বাচন করুন।
3. Gradle sync শেষ হলে ফোন USB দিয়ে যুক্ত করে Run চাপুন। চাইলে Build > Build APK(s) ব্যবহার করুন।
4. ফোনে ShortBlock খুলে **Enable ShortBlock** চাপুন।
5. Accessibility settings-এ **ShortBlock screen blocker** চালু করুন এবং অনুমতি নিশ্চিত করুন।
6. YouTube Shorts / Instagram Reels / Facebook Reels খুলে পরীক্ষা করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি একটি starter project/source code; এখানে তৈরি ও সাইন করা APK দেওয়া হয়নি। APK বানাতে Android Studio/Android SDK প্রয়োজন।
- YouTube, Instagram ও Facebook তাদের UI বদলালে screen detection কাজ নাও করতে পারে। তাই এটি best-effort blocker, শতভাগ নিশ্চয়তা নয়।
- Accessibility permission শক্তিশালী অনুমতি। এই অ্যাপ screen-এর দৃশ্যমান text ও view identifiers ডিভাইসেই পরীক্ষা করে; কোনো server-এ পাঠানোর network permission নেই।
- Android-এর Accessibility settings থেকে যেকোনো সময় service বন্ধ করা যাবে।
